HELI By Phil Hite 2021 Version 1.8
A Freeware Game for the ZX Spectrum 48K/128K

Build the Bridge
Stop the Flood
Beware of Octopuses!

Keys:
O=Left
P=Right
Space= Pick Up/Drop
M=Sound Off/On
H=Hold
S=Start
Q=Quit
I=Instructions

HELI.tzx
LOAD "heli"

https://www.worldofspectrum.org
https://spectrumcomputing.co.uk
Thank you to everyone on the World of Spectrum and Spectrum Computing forums for your advice and encouragement.

https://s3-eu-west-1.amazonaws.com/plhite.web/spectrum/index.html
phil_hite@hotmail.com

16 July 2021